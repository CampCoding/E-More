export const storeToken = (token) => localStorage.setItem("e_token", token);
export const getToken = () => localStorage.getItem("e_token");
