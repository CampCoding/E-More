
 export const  questions = [
      {
        "question": "What is the most common congenital male reproductive disorder?",
        "options": ["Hydrocoele", "Peyronie's disease", "Cryptorchidism", "Testicular torison"],
        "correctOption": 1,
        "points": 10
      },
      {
        "question": "What is the causative agent of condyloma acuminatum?",
        "options": ["HPV 6 or 11", "HSV", "E coli", "Chlamydia trachomatics"],
        "correctOption": 3,
        "points": 10
      },
      {
        "question": "What is the risk factors for developing germ cell tumours?",
        "options": ["Orchitis", "Hypospadias and epispadias", "Klinefelter syndrome and Cryptorchidism", "Hydrocoele and varicocele"],
        "correctOption": 0,
        "points": 10
      },
      {
        "question": "What area does prostate cancer spread to most frequently?",
        "options": ["Pancreas", "Lung", "Lumbar spine", "Brain"],
        "correctOption": 2,
        "points": 10
      },
      {
        "question": "How does testicular torison typically present?",
        "options": [
          "Sudden pain in the scrotum and an absent  cremasteric reflex",
          "Swelling of the  scrotum and fever",
          "A painful testicular mass that cannot be transilluminated",
          "'Bag of worms' appearence of scortum"
        ],
        "correctOption": 0,
        "points": 10
      },
      {
        "question": "what is priaprism?",
        "options": ["painful erection lasting > 4 hours", "Abnormal curvature of the peins", "inability to void the bladder", "Cyst due to  dialted testicular duct"],
        "correctOption": 1,
        "points": 10
      },
      {
        "question": "Are testicular tumours usually biopsied",
        "options": [
          "No",
          "Yes"
        ],
        "correctOption": 1,
        "points": 30
      },
      {
        "question": "What triggers a UI re-render in React?",
        "options": [
          "Running an effect",
          "Passing props",
          "Updating state",
          "Adding event listeners to DOM elements"
        ],
        "correctOption": 2,
        "points": 20
      },
      {
        "question": "What is the best description for the area of the prostate that the carcinoma usually affects?",
        "options": [
          "Periurethral region",
          "Anterior and peripheral region",
          "entire anterior region",
          "Posterior and peripheral region"
        ],
        "correctOption": 3,
        "points": 20
      },
      {
        "question": "What tumour is characterisec by finding of 'Schiller Duval bodies' on histology amd raised level of AFP on blod tests?",
        "options": [
          "Sertoli cell tumour",
          "Teratoma",
          "Yolk sac tumour",
          "Embryonel carcinoma"
        ],
        "correctOption": 3,
        "points": 30
      },
      {
        "question": "What is the grading system for  prostatic cancer?",
        "options": [
          "Breslow thickness",
          "Gleason",
          "Fuhrman",
          "Bloom Richardson"
        ],
        "correctOption": 2,
        "points": 30
      },
      {
        "question": "What is hypospadisa?",
        "options": ["Opening of urethra on dorsal surface of the peins", "Benign warty growth on genital skin", "Opening of urethra on the vental surface of the peins", "inflammation of the testicles"],
        "correctOption": 1,
        "points": 10
      }
    ]
