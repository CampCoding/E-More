export const universitiesData=[
  {
    uni_id:1,
    uni_name:'must',
  },
  {
    uni_id:2,
    uni_name:'tanta',
  },
  {
    uni_id:3,
    uni_name:'el-kasr elainy',
  },
  {
    uni_id:4,
    uni_name:'ain shams',
  },
]
