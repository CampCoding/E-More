export const CartData={
  courses:[
    {

    }
  ],
  books:[

  ]
}
