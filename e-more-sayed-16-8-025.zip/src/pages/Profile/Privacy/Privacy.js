import React from 'react'
import Modal from '../../../components/modal'

const Privacy = ({privacy}) => {
  return (
    <div>
        <p>{privacy}</p>
    </div>
  )
}

export default Privacy
