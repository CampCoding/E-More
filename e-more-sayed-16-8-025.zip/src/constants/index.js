export const base_url = "https://camp-coding.tech/emore/";
export const admin_base_url = "https://camp-coding.tech/emore/";
